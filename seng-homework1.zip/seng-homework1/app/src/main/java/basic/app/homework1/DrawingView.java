package basic.app.homework1;


import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class DrawingView extends View
{

    private Path paintPath;
    private Bitmap canBitmap;
    private Paint  canPaint;
    private Canvas drawCanvas;
    private int paintColor = 0xFFFFFF;
    private Paint drawPaint;



    public DrawingView(Context context, AttributeSet trib)
    {
        super(context, trib);
        startDrawing();
    }
    private void startDrawing()
    {
        paintPath = new Path();
        drawPaint = new Paint();
        drawPaint.setColor(paintColor);
        drawPaint.setAntiAlias(true);
        drawPaint.setStrokeWidth(20);
        drawPaint.setStyle(Paint.Style.STROKE);
        drawPaint.setStrokeJoin(Paint.Join.ROUND);
        drawPaint.setStrokeCap(Paint.Cap.ROUND);
        canPaint = new Paint(Paint.DITHER_FLAG);

    }

    @Override
    protected void onSizeChanged(int width, int height, int oldWidth,int oldHeight)
    {
        super.onSizeChanged(height, width, oldWidth, oldHeight);
        canBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ALPHA_8);
        drawCanvas = new Canvas(canBitmap);

    }

    @Override
    protected void onDraw(Canvas canvas)
    {
        canvas.drawBitmap(canBitmap, 0, 0, canPaint);

        canvas.drawPath(paintPath, drawPaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event)
    {
        float touchX = event.getX();
        float touchY = event.getY();


        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                paintPath.moveTo(touchX, touchY);

                break;
            case MotionEvent.ACTION_MOVE:
                paintPath.lineTo(touchX, touchY);

                break;
            case MotionEvent.ACTION_UP:
                drawCanvas.drawPath(paintPath, drawPaint);
                paintPath.reset();
                invalidate();
                break;
            default:
                return false;
        }
        invalidate();
        return true;
    }

    public void setColor(int red, int gre, int blu)
    {
        invalidate();
        Paint realColor = new Paint();
        realColor.setStrokeWidth(30);
        realColor.setStyle(Paint.Style.STROKE);

        paintColor = Color.argb(255, red, gre, blu);

        this.drawPaint = realColor;
        realColor.setColor(paintColor);

    }

    public void newStart()
    {
        drawCanvas.drawColor(0, PorterDuff.Mode.CLEAR);
        invalidate();
    }
}