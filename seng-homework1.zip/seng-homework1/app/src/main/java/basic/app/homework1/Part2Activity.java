package basic.app.homework1;


import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.view.View.OnClickListener;

import androidx.appcompat.app.AppCompatActivity;

public class Part2Activity extends AppCompatActivity implements OnClickListener
{
    private DrawingView drawView;
    private float sBrush, mBrush, lBrush;
    private Button newBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_part2);
        drawView = findViewById(R.id.drawing);
        EditText redBtn = findViewById(R.id.red_val);
        EditText grnBtn = findViewById(R.id.green_val);
        EditText blueBtn = findViewById(R.id.blue_val);

        sBrush = getResources().getInteger(R.integer.small_size);
        mBrush = getResources().getInteger(R.integer.medium_size);
        lBrush = getResources().getInteger(R.integer.large_size);

        redBtn.setOnClickListener(v -> paintColor(v));
        grnBtn.setOnClickListener(v -> paintColor(v));
        blueBtn.setOnClickListener(v -> paintColor(v));

        newBtn = findViewById(R.id.new_btn);
        newBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View view)
    {
        if(view.getId()==R.id.new_btn)
        {
            AlertDialog.Builder newDialog = new AlertDialog.Builder(this);
            newDialog.setTitle("New drawing");
            AlertDialog.Builder builder = newDialog.setMessage("Start new drawing (you will lose the current drawing)?");
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener(){
                public void onClick(DialogInterface dialog, int which){
                    drawView.newStart();
                    dialog.dismiss();
                }
            });
            newDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener(){
                public void onClick(DialogInterface dialog, int which){
                    dialog.cancel();
                }
            });
            newDialog.show();
        }
    }
    public void paintColor(View view)
    {
            EditText redBtn = findViewById(R.id.red_val);
            EditText grnBtn = findViewById(R.id.green_val);
            EditText blueBtn = findViewById(R.id.blue_val);

            int red = Integer.parseInt(redBtn.getText().toString());
            int green = Integer.parseInt(grnBtn.getText().toString());
            int blue = Integer.parseInt(blueBtn.getText().toString());

            drawView.setColor(red, green, blue);
    }
}
